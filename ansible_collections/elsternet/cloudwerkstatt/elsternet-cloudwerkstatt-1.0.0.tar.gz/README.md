# Ansible Collection - elsternet.cloudwerkstatt

Documentation for the collection.

## Roles

- [local_accounts](https://github.com/elsternet/cloudwerkstatt/blob/main/ansible_collections/elsternet/cloudwerkstatt/roles/local_accounts/README.md)
- [ssh_config](https://github.com/elsternet/cloudwerkstatt/blob/main/ansible_collections/elsternet/cloudwerkstatt/roles/ssh_config/README.md)
