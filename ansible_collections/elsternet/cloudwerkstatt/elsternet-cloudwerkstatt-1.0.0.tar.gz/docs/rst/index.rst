
.. Created with antsibull-docs 2.10.0

.. _docsite_root_index:

Welcome to my Ansible collection documentation
==============================================

This docsite contains documentation of elsternet.cloudwerkstatt.


.. toctree::
   :maxdepth: 2
   :caption: Collections:

   collections/index


.. toctree::
   :maxdepth: 1
   :caption: Plugin indexes:
   :glob:

   collections/index_*


.. toctree::
   :maxdepth: 1
   :caption: Reference indexes:

   collections/environment_variables
